arXiv source package for:
GUI State Compression for Computer-Use Agents Using Keyframes and Delta Encoding

Top-level TeX file:
main.tex

Expected compiler:
PDFLaTeX

The code and benchmark artifacts are available at:
https://github.com/sauravtom/gui-state-compression
